<?php
session_start();
include("connectdb.php");

$user=$_SESSION['userprofile'];
$sql ="SELECT * FROM userdata where username ='$user'" ;
$result=$conn->query($sql);
while($row=$result->fetch_assoc()){
$fname=$row['username'];
$lname=$row['lname'];
$mail=$row['email'];
$pass=$row['password'];
$phone=$row['Phone_Number'];
$city=$row['city'];
$state=$row['state'];
}
?>        



<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Light Bootstrap Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>

$(document).ready(function(){


    $("#fname").change(function(){
     var x;
      x=document.getElementById("fname").value  ; 
      
     if(x.length<=6)  
       {  
      document.getElementById("a1").innerHTML="Atleast 6 characters"; 
      x.focus();
      return false;
         }  
 
else{
 document.getElementById("a1").innerHTML=""; 
 return true;
}

    });


$("#Uname").change(function(){
     var x;
      x=document.getElementById("Uname").value  ; 
      
     if(x.length<=6)  
       {  
      document.getElementById("a3").innerHTML="Invalid one"; 
      x.focus();
      return false;
         }  
 
else{
 document.getElementById("a3").innerHTML=""; 
 return true;
}

    });


$("#phno").change(function(){
     var x;
      x=document.getElementById("phno").value  ; 
     
     if(x.length<10)  
       {  
      document.getElementById("a5").innerHTML="Invalid one"; 
      x.focus();
      return false;
         }  
 else{
 document.getElementById("a5").innerHTML=""; 
 return true;
}

    });



  $("#pwd").change(function(){
    
     var y;
      y=document.getElementById("pwd").value  ;
      if(y.length<6){ 
 document.getElementById("a6").innerHTML="Atleast 7 characters";  
 return false; 
  }else{
 document.getElementById("a6").innerHTML=""; 
 return true;
}

    });


$("#cpwd").change(function(){
    
     var y;
      y=document.getElementById("cpwd").value  ;
      x=document.getElementById("pwd").value  ;
      if(y!=x){ 
 document.getElementById("a7").innerHTML="password should match"; 
 return false;  
  }else{
 document.getElementById("a7").innerHTML=""; 
 return true;
}

    });



});




</script>








</head>
<body>

<div class="wrapper" method="post" >
    <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-5.jpg">

    <!--   you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple" -->


    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    NOTARY HUB
                </a>
            </div>

            <ul class="nav">
                <li>
                    <a href="DashBoard.php">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="active">
                    <a href="user.php">
                        <i class="pe-7s-user"></i>
                        <p>User Profile</p>
                    </a>
                </li>
               <li>
                    <a href="documents.php">
                        <i class="pe-7s-note2"></i>
                        <p>Document List</p>
                    </a>
                </li>
                <li>
                    <a href="payment.php">
                        <i class="pe-7s-cash"></i>
                        <p>Payment</p>
                    </a>
                </li>
               
                <li>
                    <a href="settings.php">
                        <i class="pe-7s-config"></i>
                        <p>settings</p>
                    </a>
                </li>
			<!--	<li class="active-pro">
                    <a href="upgrade.html">
                        <i class="pe-7s-rocket"></i>
                        <p>Upgrade to PRO</p>
                    </a>
                </li> -->
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    
                    <a class="navbar-brand" href="#">Profile</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                       
                           
                      
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="">
                               
                            </a>
                        </li>
                       <!-- <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    Dropdown
                                    <b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>
                        </li> -->
                        <li>
                            <a href="logout.php">
                                Log out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit Profile</h4>
                            </div>
                            <div class="content">
                                <form method="POST" name="proform" action="editdb.php">
                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>First Name</label>
                                                <input type="text" class="form-control"  name="fname" id="fname" placeholder="First Name" required value="<?php echo $fname ?>"><span id="a1"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Last Name</label>
                                                <input type="text" class="form-control" name="lname" id="lname" placeholder="Last Name" required value="<?php echo $lname ?>"><span id="a2"></span>
                                            </div>
                                        </div>
                                    </div>
                                       <div class="row">
                                       
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input type="email" class="form-control"  name="email" id="email" placeholder="Email"  value="<?php echo $mail ?>">
                                            </div>
                                        </div>
                                       <!--
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Company (disabled)</label>
                                                <input type="text" class="form-control" disabled placeholder="Company" >
                                            </div>
                                        </div> -->
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Phone Number</label>
                                                <input type="text" class="form-control"  name="phone" id="phno" placeholder="Phone Number" value="<?php echo $phone ?>" required><span id="a5"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Password</label>
                                                <input type="password" class="form-control" name="password" id="pwd"  placeholder="password" value="<?php echo $pass ?>" required ><span id="a6"></span>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" class="form-control" name="city"  placeholder="Your City Name"  value="<?php echo $city ?>" >
                                            </div>
                                        </div>

                                      <div class="col-md-5">
                                            <div class="form-group">
                                                <label>State</label>
                                                <input type="text" class="form-control" name="state"  placeholder="Enter your State" value="<?php echo $state ?>">
                                            </div>
                                        </div>
                                    </div>
                                 <!--
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <textarea rows="5" class="form-control" placeholder="Here can be your description" value="Mike"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                 -->

                        
                                    <button type="submit" class="btn btn-info btn-fill pull-right" name="update" onclick="validateform1()">Update Profile</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                                <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                    <img class="avatar" src="assets/img/faces/face-3.jpg" alt="..."/>

                                      <h4 class="title"><?php echo $lname ?><?php echo " " ?> <?php echo $fname ?><br />
                                         <small><?php echo $phone ?></small>
                                      </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> <?php echo $mail ?>
                                </p>
                            </div>
                            <hr>
                            <div class="text-center">
                                <button href="#" class="btn btn-simple"><i class="fa fa-facebook-square"></i></button>
                                <button href="#" class="btn btn-simple"><i class="fa fa-twitter"></i></button>
                                <button href="#" class="btn btn-simple"><i class="fa fa-google-plus-square"></i></button>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="#">
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Company
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Portfolio
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; 2016 <a href="http://www.creative-tim.com">NOTARY HUB</a>, made with love for a better web
                </p>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script> 
        <script src="js/validation.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

</html>
