<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Online Login Form Responsive Widget Template :: w3layouts</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Online Login Form Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Meta tag Keywords -->
<!-- css files -->
<link rel="stylesheet" href="css/style12.css" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome12.css"> <!-- Font-Awesome-Icons-CSS -->
<!-- //css files -->
<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800&amp;subset=latin-ext" rel="stylesheet">
<!-- //online-fonts -->






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>

$(document).ready(function(){


    $("#fname").change(function(){
     var x;
      x=document.getElementById("fname").value  ; 
      
     if(x.length<=6)  
       {  
      document.getElementById("a1").innerHTML="Atleast 6 characters"; 
      fname.focus();
      return false;
         }  
 
else{
 document.getElementById("a1").innerHTML=""; 
 return true;
}

    });


$("#Uname").change(function(){
     var x;
      x=document.getElementById("Uname").value  ; 
      
     if(x.length<=6)  
       {  
      document.getElementById("a3").innerHTML="Invalid one"; 
      x.focus();
      return false;
         }  
 
else{
 document.getElementById("a3").innerHTML=""; 
 return true;
}

    });


$("#phno").change(function(){
     var x;
      x=document.getElementById("phno").value  ; 
     
     if(x.length<10)  
       {  
      document.getElementById("a5").innerHTML="Invalid one"; 
      x.focus();
      return false;
         }  
 else{
 document.getElementById("a5").innerHTML=""; 
 return true;
}

    });



  $("#pwd").change(function(){
    
     var y;
      y=document.getElementById("pwd").value  ;
      if(y.length<6){ 
 document.getElementById("a6").innerHTML="Atleast 7 characters";  
 return false; 
  }else{
 document.getElementById("a6").innerHTML=""; 
 return true;
}

    });


$("#cpwd").change(function(){
    
     var y;
      y=document.getElementById("cpwd").value  ;
      x=document.getElementById("pwd").value  ;
      if(y!=x){ 
 document.getElementById("a7").innerHTML="password should match"; 
 return false;  
  }else{
 document.getElementById("a7").innerHTML=""; 
 return true;
}

    });



});




</script>

<script type="text/javascript">
	// GETTING ALL INPUT TEXT FIELDS
	var fname = document.forms["myform"]["fname"];
	var email = document.forms["vForm"]["email"];
	var password = document.forms["vForm"]["password"];
	var password_confirmation = document.forms["vForm"]["password_confirmation"];

	// GETTING ALL ERROR OBJECTS
	var name_error = document.getElementById("name_error");
	var email_error = document.getElementById("email_error");
	var password_error = document.getElementById("password_error");

	// SETTING ALL EVENT LISTENERS
	username.addEventListener("blur", nameVerify, true);
	email.addEventListener("blur", emailVerify, true);

	function Validate(){
		// VALIDATE USERNAME
		if(fname.length<1){
			a1.textContent = "Username is required";
			fname.style.border = "1px solid red";
			fname.focus();
			return false;
		}

		// VALIDATE EMAIL
		if(email.value == ""){
			email_error.textContent = "Email is required";
			email.style.border = "1px solid red";
			email.focus();
			return false;
		}

		// VALIDATE PASSWORD
		if (password.value != password_confirmation.value) {
			password_error.textContent = "The two passwords do not match";
			password.style.border = "1px solid red";
			password_confirmation.style.border = "1px solid red";
			password.focus();
			return false;
		}

		// PASSWORD REQUIRED
		if (password.value == "" || password_confirmation.value == "") {
			password_error.textContent = "Password required";
			password.style.border = "1px solid red";
			password_confirmation.style.border = "1px solid red";
			password.focus();
			return false;
		}
	}

	// ADD EVENT LISTENERS
	function nameVerify(){
		if (username.value != "") {
			name_error.innerHTML = "";
			username.style.border = "1px solid #110E0F";
			return true;
		}
	}

	function emailVerify(){
		if (email.value != "") {
			email_error.innerHTML = "";
			email.style.border = "1px solid #110E0F";
			return true;
		}
	}


</script>







</head>
<body>
<!-- main -->
<div class="center-container">
	<!--header-->
	<div class="header-w3l">
		<center><h1>Notary Managment Repository</h1></center>
	</div>
	<!--//header-->
	<div class="main-content-agile">
		<div class="sub-main-w3">	
			<div class="wthree-pro">
				<center><h2><b>SignUp</b></h2></center>
			</div>
			<form action="dbregister.php" method="post" name="myform" onsubmit="return Validate()">
				<div class="pom-agile">
					<input placeholder="First Name" id="fname" name="fName" class="user" type="text">
					<span class="icon1"><i class="fa fa-user" id="a1" aria-hidden="true"></i></span>
				</div>
                                
				<div class="pom-agile">
					<input placeholder="Last Name" name="lName"  id="lname" class="user" type="text" required="">
					<span class="icon1"><i class="fa fa-user" id="a2" aria-hidden="true"></i></span>
				</div>
                                <div class="pom-agile">
					<input placeholder="UserName" name="UName" id="Uname" class="user" type="text" required="">
					<span class="icon1"><i class="fa fa-user" id="a3" aria-hidden="true"></i></span>
				</div>
                                
				<div class="pom-agile">
					<input placeholder="E-mail" name="mail" id="mail" class="user" type="text" required="">
					<span class="icon1"><i class="fa fa-user" id="a4" aria-hidden="true"></i></span>
				</div>
                                
				<div class="pom-agile">
					<input placeholder="Phone Number" name="phno" id="phno" class="user" type="text" required="">
					<span class="icon1"><i class="fa fa-user" id="a5" aria-hidden="true"></i></span>
				</div>
                                
				<div class="pom-agile">
					<input  placeholder="Password" name="Password" id="pwd" class="user" type="password" required="">
					<span class="icon2"><i class="fa fa-unlock" id="a6" aria-hidden="true"></i></span>
				</div> 
                                <div class="pom-agile">
					<input  placeholder="Confirm Password" name="cPassword" id="cpwd" class="user" type="password" required="">
					<span class="icon2"><i class="fa fa-unlock" id="a7" aria-hidden="true"></i></span>
				</div>
				<div class="sub-w3l">
					

					<div class="right-w3l">
						<h6><a href="index12.php">Already Member?</a></h6><input type="submit" value="SignUp">
                                                
					</div>
                                           
				</div>
			</form>
                   
		</div>
	</div>
	<!--//main-->
	<!--footer-->
	<div class="footer">
		
	</div>
	<!--//footer-->
</div>
</body>
</html>
